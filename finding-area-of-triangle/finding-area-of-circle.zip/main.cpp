#include <iostream>

using namespace std;

int main()
{
    float radius;
    float area;
    
    cout<<"enter radius of circle"<<endl;
    cin>>radius;
    
    area=3.1425*radius*radius;
    cout<<"area of circle is"<<area;
    
    return 0;
}